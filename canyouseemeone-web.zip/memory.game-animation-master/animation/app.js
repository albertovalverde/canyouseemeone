$( document ).ready(function() {
    var audio = new Audio('audio/bensound-buddy.mp3');
     audio.volume = 0.03;
     audio.play();
    
  $('.tex4').delay(19000)
    var audio = new Audio('audio/1.mp3');
     audio.play();
    $('.tex4').animate({opacity:'0'},1800,function(){
        var audio = new Audio('audio/5.mp3');
        audio.play();
      $('.littlewheel').animate({opacity:'0'},500,function(){
       $('.littlewheel2').animate({opacity:'1'},500,function(){
         $('.tex5').animate({opacity:'1'},500,function(){
           $('.play').animate({opacity:'1'});
           })
         })
      })
    })
  $('.section1').delay(3000).fadeOut(500,'linear',function(){
       var audio = new Audio('audio/2.mp3');
       audio.play();
    $('.section2').fadeIn(500,'linear', function(){
       ;
       $('.section2').delay(6000).fadeOut(500,'linear', function(){
            var audio = new Audio('audio/3.mp3');
            audio.play()
         $('.section3').fadeIn('linear', function(){
           $('.section3').delay(6000).fadeOut(500,'linear', function(){
               var audio = new Audio('audio/4.mp3');
               audio.play();
             $('.section4').fadeIn(500,'linear')
               
          })
        })
      })
    })
  })
});
